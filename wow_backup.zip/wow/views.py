from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm

from django.contrib.auth import authenticate, login, logout

from django.contrib import messages

from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import Group


# Create your views here.
from wow.models import *
from wow.decorators import unauthenticated_user, allowed_users, admin_only
from wow.forms import *
import datetime

import sys
import os
import django
import random

sys.path.append(r'C:\Users\Rlron\Anaconda2\envs\django\db_project\own')
os.environ['DJANGO_SETTINGS_MODULE'] = 'wow.settings'
django.setup()
os.environ["DJANGO_ALLOW_ASYNC_UNSAFE"] = "true"


def index(request):
  return render(request,'wow/index.html')

# @unauthenticated_user
def cars(request):
  cars = RrskVehicle.objects.all()
  vehicles = RrskVehicleClass.objects.raw('SELECT * FROM rrsk_vehicle_class a JOIN rrsk_vehicle b ON a.id = b.id')
  context = {'vehicles':vehicles}

  return render(request,'wow/cars.html',context)


# @unauthenticated_user
def loginPage(request):

  if request.method == 'POST':
    username = request.POST.get('username')
    password =request.POST.get('password')

    user = authenticate(request, username=username, password=password)

    if user is not None:
      login(request, user)
      return redirect('login')
    else:
      messages.info(request, 'Username OR password is incorrect')

  context = {}
  return render(request, 'wow/login.html', context)

# @unauthenticated_user
def registerPage(request):
  form = CustomerForm()
  if request.method == 'POST':
    user_form = CreateUserForm(request.POST)
    form = CustomerForm(request.POST)
    form.id = id
    if form.is_valid():# and user_form.is_valid():
      user = user_form.save()
      customer = form.save()
      #username = form.cleaned_data.get('cust_fname')
      RrskCustomers.objects.create(user=user)

      messages.success(request, 'Account was created for ' + user.username)
      return redirect('login')

  context = {'form':form}
  return render(request, 'wow/register.html', context)

def dashboard(request, pk_test):
  # Keep past orders in for loop and correct the curr_orders
  # Work on this
  pk_test = int(pk_test)
  RrskRental.objects
  past_orders = RrskRental.objects.filter(cust = pk_test, dropoff_date__lt=datetime.date.today()) #.filter(dropoff_date__lte = datetime.date(2020, 12, 17))
  if len(past_orders) > 0:
    past_orders = RrskInvoice.objects.filter(id = pk_test)#
    past_orders.refresh_from_db()

  total_orders = RrskRental.objects.filter(cust = pk_test).count()
  delivered = len(past_orders)

  # past_orders = past_orders.raw('SELECT * FROM rrsk_rental a JOIN rrsk_invoice b ON a.rental_id = b.rental_id where a.dropoff_date < sysdate()')
  # curr_orders = RrskRental.objects.raw('SELECT * FROM rrsk_rental a JOIN rrsk_invoice b ON a.rental_id = b.rental_id where a.cust_id = pk_test and a.end_odometer is NULL')
  curr_orders = RrskRental.objects.filter(cust = pk_test, dropoff_date__gte = datetime.date.today())#.filter()
  if len(curr_orders) > 0:
    curr_vehicle = RrskVehicle.objects.filter(id = curr_orders[0].v.id)
  print(curr_orders)
  pending = len(curr_orders)
  context = {'past_orders':past_orders,'curr_orders': curr_orders,'total_orders':total_orders,'delivered':delivered,'pending':pending,'id':pk_test}
  return render(request, 'wow/dashboard.html',context)


def createOrder(request, pk):
  customer = RrskCustomers.objects.get(id=pk)
  form = OrderFormCreate(instance=customer)
  if request.method == 'POST':
    form = OrderFormCreate(request.POST)
    if form.is_valid():
      rental = form.save()
      rental.refresh_from_db()
      rental.start_odometer = 10000
      rental.cust = customer
      rental.v = random.choice(RrskVehicle.objects.filter(v_model='Beatle'))
      rental.save()
      return redirect('/dashboard/' + str(pk))

  context = {'form':form}
  return render(request, 'wow/order_form_create.html', context)



def updateOrder(request, pk):
  order = RrskRental.objects.get(id=pk)
  form = OrderForm(instance=order)
  # print('ORDER:', order)
  if request.method == 'POST':

    form = OrderForm(request.POST, instance=order)
    if form.is_valid():
      form.save()#,order.generate_invoice()
      return redirect('/dashboard/' + str(order.cust.id) )

  context = {'form':form}
  return render(request, 'wow/order_form.html', context)


def deleteOrder(request, pk):
  order = RrskRental.objects.get(id=pk)
  if request.method == "POST":
    order.delete()
    return redirect('/dashboard/' + str(order.cust.id))

  context = {'item':order}
  return render(request, 'wow/delete_order.html', context)



# Still Working, this function should return pickup date, dropof date, pickup loc, dropoff loc and amount
# WOrk on this
def past(request, pk_test):

# still need to add/fix amount
  orders = RrskRental.objects.filter(id=pk_test, dropoff_date__lt=datetime.date.today()).values('pickup_date', 'dropoff_date', 'pickup_location', 'dropoff_location')
  context = {'orders':orders}
  return render(request, 'wow/past.html',context)



# def signup(request):
#     if request.method == 'POST':
#         form = SignUpForm(request.POST)
#         if form.is_valid():
#             user = form.save()
#             user.refresh_from_db()  # load the profile instance created by the signal
#             #user.RrskCustomer.cust_fname = form.cleaned_data.get('first_name')
#             user.save()
#             raw_password = form.cleaned_data.get('password1')
#             user = authenticate(username=user.username, password=raw_password)
#             login(request, user)
#             return redirect('cars')
#     else:
#         form = SignUpForm()
#     return render(request, 'signup.html', {'form': form})
####-------------------------
#%%
def generate_customers(num_customers=200):
  first_names = ['John', 'James', 'Hank', 'Tim', 'Joan','Jane', 'Willy', 'Paul','Sarah', 'Bonnie', 'Will', 'Arthur','Rudy', 'Tom', 'Liza', 'Lizze', 'Rose', 'Lily', 'Amanda']
  last_names = ['Smith', 'Stevens', 'Paulson', 'Cragson', 'Mansfield','Barmaeger', 'Wolls', 'Winner', 'Idleman', 'Shaper', 'Bolt', 'Doad']
  cities = ['New York', 'Boston', 'Philly', 'DC']

  for i in range(num_customers):
    cust = RrskCustomers(

      cust_email = '{}@gmail.com'.format(i),
      cust_phone_no = 9999999999 - i,
      cust_type = random.choice(['I', 'C']),
      cust_country = 'USA',
      cust_state = 'NY',
      cust_city = random.choice(cities),
      cust_street = '{} street'.format(i),
      cust_no = '{}'.format(i),
      cust_zip = 10000 + i,
      cust_fname = random.choice(first_names),
      cust_lname = random.choice(last_names))
    cust.save()

def generate_corporations():
  names = ['Visa', 'Mastercard', 'ABC corp', 'Dog and Co', 'Bank of America', 'Jesus Inc.', 'Hello Company', 'Yelp']
  #corp_id = models.DecimalField(primary_key=True, max_digits=32, decimal_places=0)
  for i in range(len(names)):
    corp = RrskCorporation(
       corp_reg_no = 'reg_' + str(i),
       corp_name = names[i],
       corp_discount = random.choice([0,0.1,0.2,0.25,0.205]))
    corp.save()

def generate_corp_customers():
  customers = RrskCustomers.objects.filter(cust_type='C')
  corps = RrskCorporation.objects.all()
  for i in range(len(customers)):
    corp_customer = CorpCustomer(cust=customers[i],
                                 emp_id = i**2,
                                 corp = random.choice(corps))
    corp_customer.save()



def generate_discounts(num=10):
  for i in range(num):
    disc_start_date = datetime.date.today() + datetime.timedelta(days = random.randint(-365, 365))
    disc = RrskDiscount(disc_rate= random.choice([0,0.1,0.2,0.25,0.15]),
                        disc_start_date = disc_start_date,
                        disc_end_date = disc_start_date + datetime.timedelta(days = random.randint(0, 400))
                        )
    disc.save()




def generate_ind_customers():
  customers = RrskCustomers.objects.filter(cust_type='I')
  discounts = RrskDiscount.objects.all()
  for i in range(len(customers)):
    cust = IndCustomer(
      cust = customers[i],
      driver_lisence_no = 'abcd-abcd' + str(i),
      insurance_provider = 'Aflack',
      insurance_policy_no = i,
      disc = random.choice([None, random.choice(discounts)])
      )
    cust.save()


def generate_locations(num=5):
  cities = ['New York', 'Boston', 'Philly', 'DC']

  for i in range(num):
    loc = RrskLocation(
      loc_phone_no=88888888888 - 5*i**3,
      loc_email = None,
      loc_country = 'USA',
      loc_state = 'New York',
      loc_city = random.choice(cities),
      loc_street = '{} East'.format(2 + i**2),
      loc_no = str(i),
      loc_zip = 10000 + i)
    loc.save()

def generate_vehicle_classes(num=5):
  class_name = ['Compact', 'Mid-Size', 'SUV', 'Truck', 'Limo', 'Sports']
  for i in class_name:
    vclass = RrskVehicleClass(
      class_name = i,
      daily_rate = random.randint(50,600),
      daily_mileage_limit = random.randint(100,400),
      over_mileage_fee = random.randint(1,3))
    vclass.save()


def generate_vehicles(num=70):
  models = ['Range Rover', 'Fielder', 'Icemaker', 'Blastmaster', 'Top-Heavy', 'Miatta', 'Oboe', 'Beatle', 'Bug', 'Land Cruiser', 'Big Bertha', '911 Turbo', 'Supercharger', 'Ace', 'MX123', 'Mandlevroch']
  makes = ['Toyota', 'Chevy', 'Ford', 'Porche', 'Mazda', 'Volkswagen', 'Firarri']
  classes = RrskVehicleClass.objects.all()
  locations = RrskLocation.objects.all()
  for i in range(70):
    v = RrskVehicle(
      vin = str(random.randint(1,10000)),
      v_make = random.choice(makes),
      v_model = random.choice(models),
      liscence_plate_no = i,
      available = 'Y',
      v_class = random.choice(classes),
      loc = random.choice(locations))
    v.save()






def generate_rentals(pickup_date = None, dropoff_date = None, v=None, num=400):
  if pickup_date is None and dropoff_date is None and v is None:
    for i in range(num):
      dropoff_location = random.choice(RrskLocation.objects.all())
      v = random.choice(RrskVehicle.objects.filter(loc=dropoff_location))
      v_class = RrskVehicle.objects.get(pk=v.pk).v_class
      pickup_date = datetime.date.today() + datetime.timedelta(days=random.randint(-20, 30))
      dropoff_date = pickup_date + datetime.timedelta(days=random.randint(1, 14))
      start_odometer = random.randint(1,100000)

      if dropoff_date < datetime.date.today():
        end_odometer = start_odometer + random.randint(100, 30000)
      else:
        end_odometer = None
      rental = RrskRental(pickup_date = pickup_date,
                 dropoff_date = dropoff_date,
                 start_odometer = start_odometer,
                 end_odometer = end_odometer,
                 unlimited_mileage = random.choice(['Y', 'N']),
                 cust = random.choice(RrskCustomers.objects.all()),
                 dropoff_location = dropoff_location,
                 v = v,
                 pickup_location = dropoff_location,
                 v_class = v,
                 loc = v)
      rental.save()


def generate_all():
  generate_customers()
  generate_corporations()
  generate_corp_customers()
  generate_discounts()
  generate_ind_customers()
  generate_locations()
  generate_vehicle_classes()
  generate_vehicles()
  generate_rentals()











