from django.apps import AppConfig


class WowConfig(AppConfig):
    name = 'wow'
