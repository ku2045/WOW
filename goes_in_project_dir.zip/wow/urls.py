from django.urls import path

from django.contrib.auth import views as auth_views

from . import views

urlpatterns = [
				
				path('', views.index, name="index"),
				path('cars/',views.cars, name="cars"),
				path('login/', views.loginPage, name="login"),
				path('register/', views.registerPage, name="register"),
				path('dashboard/<str:pk_test>/', views.dashboard, name="dashboard"),
				path('create_order/<str:pk>/', views.createOrder, name="create_order"),
				path('update_order/<str:pk>/', views.updateOrder, name="update_order"),
    			path('delete_order/<str:pk>/', views.deleteOrder, name="delete_order"),
    			path('past/<str:pk_test>/', views.past, name="past"),

]


'''
1 - Submit email form                         //PasswordResetView.as_view()
2 - Email sent success message                //PasswordResetDoneView.as_view()
3 - Link to password Rest form in email       //PasswordResetConfirmView.as_view()
4 - Password successfully changed message     //PasswordResetCompleteView.as_view()
'''