# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models
import datetime


class CorpCustomer(models.Model):
    cust = models.OneToOneField('RrskCustomers', models.DO_NOTHING)#, primary_key=True)
    emp_id = models.DecimalField(max_digits=32, decimal_places=0)
    corp = models.ForeignKey('RrskCorporation', models.DO_NOTHING)

    class Meta:
        managed = True
        db_table = 'corp_customer'
    def __str__(self):
        return ''.join([self.cust.cust_fname,' ', self.cust.cust_lname])


class IndCustomer(models.Model):
    cust = models.OneToOneField('RrskCustomers', models.DO_NOTHING)#, primary_key=True)
    driver_lisence_no = models.CharField(max_length=12)
    insurance_provider = models.CharField(max_length=64)
    insurance_policy_no = models.DecimalField(max_digits=32, decimal_places=0)
    disc = models.ForeignKey('RrskDiscount', models.DO_NOTHING, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'ind_customer'
    def __str__(self):
        return ''.join([self.cust.cust_fname,' ', self.cust.cust_lname])


class RrskCorporation(models.Model):
    #corp_id = models.DecimalField(primary_key=True, max_digits=32, decimal_places=0)
    corp_reg_no = models.CharField(max_length=32)
    corp_name = models.CharField(max_length=64)
    corp_discount = models.DecimalField(max_digits=4, decimal_places=4, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'rrsk_corporation'
    def __str__(self):
        return self.corp_name

class RrskCustomers(models.Model):
    cust_email = models.CharField(max_length=64)
    cust_phone_no = models.BigIntegerField()
    cust_type = models.CharField(max_length=1)
    cust_country = models.CharField(max_length=32)
    cust_state = models.CharField(max_length=32)
    cust_city = models.CharField(max_length=32)
    cust_street = models.CharField(max_length=64)
    cust_no = models.CharField(max_length=32)
    cust_zip = models.IntegerField()
    cust_fname = models.CharField(max_length=32)
    cust_lname = models.CharField(max_length=32)

    class Meta:
        managed = True
        db_table = 'rrsk_customers'
    def __str__(self):
        return ''.join([self.cust_fname,' ', self.cust_lname])

class RrskDiscount(models.Model):
    #disc_id = models.BigIntegerField(primary_key=True)
    disc_rate = models.DecimalField(max_digits=4, decimal_places=4)
    #disc_type = models.CharField(max_length=1)
    disc_start_date = models.DateTimeField()
    disc_end_date = models.DateTimeField()

    def is_valid(self):
      if self.disc_start_date > datetime.date.today():
        return False
      if self.disc_end_date < datetime.date.today():
        return False
      return True

    class Meta:
        managed = True
        db_table = 'rrsk_discount'

class RrskInvoice(models.Model):
    #invoice_no = models.BigIntegerField(primary_key=True)
    invoice_date = models.DateTimeField()
    invoice_amount = models.DecimalField(max_digits=9, decimal_places=2)
    rental = models.OneToOneField('RrskRental', models.DO_NOTHING)

    class Meta:
        managed = True
        db_table = 'rrsk_invoice'


class RrskInvoicePayment(models.Model):
    #pay_id = models.BigIntegerField(primary_key=True)
    pay_amount = models.DecimalField(max_digits=9, decimal_places=2)
    pay_date = models.DateTimeField()
    pay_method = models.CharField(max_length=16)
    card_no = models.DecimalField(max_digits=19, decimal_places=0)
    invoice_no = models.ForeignKey(RrskInvoice, models.DO_NOTHING)#, db_column='invoice_no')

    class Meta:
        managed = True
        db_table = 'rrsk_invoice_payment'


class RrskLocation(models.Model):
    #loc_id = models.BigIntegerField(primary_key=True)
    loc_phone_no = models.BigIntegerField()
    loc_email = models.CharField(max_length=64, blank=True, null=True)
    loc_country = models.CharField(max_length=32)
    loc_state = models.CharField(max_length=32)
    loc_city = models.CharField(max_length=32)
    loc_street = models.CharField(max_length=64)
    loc_no = models.CharField(max_length=32)
    loc_zip = models.IntegerField()

    class Meta:
        managed = True
        db_table = 'rrsk_location'
    def __str__(self):
        return ''.join([self.loc_street,' ',self.loc_city,' ',self.loc_country])

class RrskRental(models.Model):
    #rental_id = models.BigIntegerField(primary_key=True)
    pickup_date = models.DateTimeField()
    dropoff_date = models.DateTimeField()
    start_odometer = models.DecimalField(max_digits=9, decimal_places=3, blank=True, null=True)
    end_odometer = models.DecimalField(max_digits=9, decimal_places=3, blank=True, null=True)
    unlimited_mileage = models.CharField(max_length=1)
    cust = models.ForeignKey(RrskCustomers, models.DO_NOTHING)
    dropoff_location = models.ForeignKey(RrskLocation, models.DO_NOTHING, related_name='rental_dropoff_location')
    pickup_location = models.ForeignKey(RrskLocation, models.DO_NOTHING, related_name='rental_pickup_location')
    v_class = models.ForeignKey('RrskVehicle', models.DO_NOTHING, related_name='rental_vehicle_class')#, db_column='class_id'  # Field renamed because it was a Python reserved word.
    loc = models.ForeignKey('RrskVehicle', models.DO_NOTHING, related_name='rental_vehicle_location')
    v = models.ForeignKey('RrskVehicle', models.DO_NOTHING, related_name='rental_vehicle_id')
    def generate_invoice(self):

      vehicle_class = RrskVehicleClass.objects.get(self.v_class)
      days_rented = (self.dropoff_date - self.pickup_date).days
      over_milage = max(0, (self.end_odometer - self.start_odometer) - days_rented*vehicle_class.daily_mileage_limit)


      if self.unlimited_mileage:
       rental_cost = vehicle_class.daily_rate*days_rented
      else:
        rental_cost = (vehicle_class.daily_rate*days_rented
                       + over_milage*vehicle_class.over_mileage_fee)

      if self.cust.type == 'C':
        corp_cust = CorpCustomer.objects.get(pk=self.cust)
        discount = RrskCorporation.objects.get(pk=corp_cust.corp).corp_discount


      elif (self.cust.type == 'I'
            and IndCustomer.objects.get(pk=self.cust).disc__isnll==False
            and IndCustomer.objects.get(pk=self.cust).disc.is_valid()):
        discount = IndCustomer.objects.get(pk=self.cust).disc.disc_rate
      else:
        discount = 0

      rental_cost = rental_cost*(1 - discount)
      rental_invoice = RrskInvoice(invoice_date=datetime.date.today(),
                                   invoice_amount=rental_cost,
                                   rental = self.pk)
      rental_invoice.save()



    class Meta:
        managed = True
        db_table = 'rrsk_rental'
    def __str__(self):
        return ''.join([str(self.id),' ',self.cust.cust_fname, ' ', self.cust.cust_lname])

class RrskVehicle(models.Model):
    #v_id = models.DecimalField(max_digits=32, decimal_places=0, primary_key=True)
    vin = models.CharField(max_length=17)
    v_make = models.CharField(max_length=20)
    v_model = models.CharField(max_length=32)
    liscence_plate_no = models.CharField(max_length=12)
    available = models.CharField(max_length=1)
    v_class = models.ForeignKey('RrskVehicleClass', models.DO_NOTHING)#, db_column='class_id')  # Field renamed because it was a Python reserved word.
    loc = models.ForeignKey(RrskLocation, models.DO_NOTHING)

    class Meta:
        managed = True
        db_table = 'rrsk_vehicle'
        unique_together = (('v_class', 'loc', 'id'),)
    def __str__(self):
        return ''.join([str(self.id), ' ', self.v_make, ' ', self.v_model , ' -- ',  str(self.loc)])

class RrskVehicleClass(models.Model):
    #class_id = models.BigIntegerField(primary_key=True)
    class_name = models.CharField(max_length=32)
    daily_rate = models.DecimalField(max_digits=7, decimal_places=2)
    daily_mileage_limit = models.IntegerField()
    over_mileage_fee = models.DecimalField(max_digits=5, decimal_places=2)

    class Meta:
        managed = True
        db_table = 'rrsk_vehicle_class'

    def __str__(self):
        return self.class_name