from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms

from wow.models import *

class CustomerForm(ModelForm):
	class Meta:
		model = RrskCustomers
		fields = ['id','cust_fname','cust_lname','cust_phone_no','cust_country','cust_state','cust_city','cust_street','cust_no','cust_zip']
		exclude = ['user']

class OrderForm(ModelForm):
	class Meta:
		model = RrskRental
		fields = ['pickup_date','dropoff_date','pickup_location','dropoff_location']


class CreateUserForm(UserCreationForm):
	class Meta:
		model = User
		fields = ['username', 'email', 'password1', 'password2']

